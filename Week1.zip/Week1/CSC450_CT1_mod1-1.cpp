/* Simple Program with a few Errors for Correction
Please be sure to correct all outlined errors.
*/

#include <iostream>
#include <conio.h>

// Standard namespace declaration
using namespace std;

// Main Function
int main()
{
    // Standard Output Statement
    cout << "Welcome to this C++ Program" << endl;
    cout << "I have corrected all errors for this program." << endl;

    // Wait For Output Screen
    getch(); // Waits for a key press

    // Main Function return Statement
    return 0;
}
